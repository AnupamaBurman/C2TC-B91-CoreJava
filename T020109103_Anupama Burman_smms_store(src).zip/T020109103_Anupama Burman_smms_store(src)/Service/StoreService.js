import axios from "axios";

const PRO_BASE_API='http://localhost:8081/store';

class StoreService
{
    getAllStores(){
        return axios.get(PRO_BASE_API);
    }

    getStoresById(storeId){
        return axios.get(PRO_BASE_API+'/'+storeId);
    }

    createStores(store){
        return axios.post(PRO_BASE_API,store);
    }

    updateStores(storeID,store){
        return axios.put(PRO_BASE_API+'/'+storeID,store);
    }

    deleteStores(storeID){
        return axios.delete(PRO_BASE_API+'/'+storeID);
    }
}

export default new StoreService();