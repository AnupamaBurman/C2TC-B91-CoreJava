import React,{useState, useEffect} from 'react';
import StoreService from '../Service/StoreService';
import {Link} from 'react-router-dom'
function Store()
{
    const [stores,setPost]=useState([]);
    const [id,setid]=useState("");

    function del(id,e)
    {
        StoreService.deleteStores(id)
            .then(res =>{
                alert("store with ID: "+id+" Successfully deleted");
                window.location.reload(true);
              
            })
            .catch(err=>{
                console.log(err)
            })
    }

    useEffect(()=>{
        StoreService.getAllStores()
            .then(res =>{
                setPost(res.data)
            })
            .catch(err=>{
                console.log(err)
            })
    },[])
    return(
        <div>
            <div id="na">
                <form onSubmit={del(id)}>
                    <Link to="/add" className='add btn'>ADD</Link>
                    OR Select to remove
                    <select name="id" value={id} onChange={(e)=>setid(e.target.value)}>
                        <option>Select store id</option>
                        {
                        stores.map(post=>(
                        <option value={post.storeId}>{post.storeId}</option>    
                        ))
                        }
                    </select>
                </form>
            </div>
            <main>
            <table cellPadding={15} cellSpacing={10} align='center' border={1}> 
                <tr>
                    <th>Store Id</th>
                    <th>Name</th>
                    <th>Category</th>
                    <th>Contact</th>
                    <th>Location</th>
                    <th>Operating Hours</th>
                    <th>Action</th>
                </tr>
                {
                    stores.map(post=>(
                        <tr>
                            <td>{post.storeId}</td>
                            <td>{post.name}</td>
                            <td>{post.category}</td>
                            <td>{post.contact_Info}</td>
                            <td>{post.location}</td>
                            <td>{post.operatinghours}</td>
                            <td><Link to={"/upd/"+post.storeId} className='upd btn'>Update</Link></td>
                        </tr>    
                ))
                }  
            </table>
            </main>
        </div>
    );
}
export default Store;