import React,{useState, useEffect} from 'react';
import StoreService from '../Service/StoreService';
function Home()
{
    const [stores,setPro]=useState([]);

    useEffect(()=>{
        getAllstores()
    },[])

    const getAllstores=()=>{
        StoreService.getAllStores()
        .then((res)=>{
            setPro(res.data)
        })
        .catch(err=>{
            console.log(err)
        })
    }
    return(
        <main>
            <table cellPadding={10} cellSpacing={10} align='center' border={1}> 
                <tr>
                    <th>Store Id</th>
                    <th>Name</th>
                    <th>Category</th>
                    <th>Contact</th>
                    <th>Location</th>
                    <th>Operating Hours</th>
                </tr>
                {
                    stores.map(post=>(
                        <tr>
                            <td>{post.storeId}</td>
                            <td>{post.name}</td>
                            <td>{post.category}</td>
                            <td>{post.contact_Info}</td>
                            <td>{post.location}</td>
                            <td>{post.operatinghours}</td>
                        </tr>    
                ))
                }  
            </table>           
        </main>
    );
}
export default Home;