import React from 'react'

export default function Foot()
{
    const ver="$ }-{ @ }-{"
    return(
        <footer>
            <address>{ver} has all copyrights &copy; reserved from 2024</address>
        </footer>
    );
}