import React,{useState,useEffect} from 'react'
import Proser from '../Service/StoreService'
import { useParams } from 'react-router-dom';

function Upd()
{
    const { id } = useParams();
    const [name,setName]=useState("");
    const [category,setCategory]=useState("");
    const [contact_Info,setContact_info]=useState("");
    const [location,setLocation]=useState("");
    const [OperatingHours,setOphr]=useState("");
    const [pro,srtpro]=useState([]);
    const obj={
        storeId:id,
        name:name,
        category:category,
        contact_Info:contact_Info,
        location:location,
        operatinghours:OperatingHours};

    const handelEve=(e)=>{
        e.preventDefault();
            Proser.updateStores(id,obj)
            .then((res)=>{
                console.log(res);
            })
            .catch(err=>{
                console.log(err);
            })
        alert("Store updated successfully.,")

    }

    function getStoreById(id){
        Proser.getStoresById(id)
        .then((res)=>{
            srtpro(res.data)
        })
        .catch(err=>{
            console.log(err)
        })
    }

    useEffect(()=>{     
        getStoreById(id);
    })

    return(
        <div id="con">
            <h2>Update Store</h2>
            <form style={{display:'grid', gridTemplateColumns:'auto auto'}}>
                <div style={{width:'30rem', textAlign:'right'}}>
                    <h3 style={{marginBottom:'30px'}}>Store Id: {pro.storeId}</h3>
                    <h3 style={{marginBottom:'30px'}}>Name: {pro.name}</h3>
                    <h3 style={{marginBottom:'30px'}}>Category: {pro.category}</h3>
                    <h3 style={{marginBottom:'30px'}}>Contact: {pro.contact_Info}</h3>
                    <h3 style={{marginBottom:'30px'}}>Location: {pro.location}</h3>
                    <h3 style={{marginBottom:'30px'}}>Pperating hours: {pro.operatinghours}</h3>
                </div>
                <div style={{textAlign:'left'}}>
                    <input disabled placeholder="Enter Store Id" type='text' name='id' value={id}/><br/>
                    <input placeholder="Enter  Name" type='text' name='name' value={name} onChange={(e)=>setName(e.target.value)} /><br/>
                    <input placeholder="Enter  Category" type='text' name='desc' value={category} onChange={(e)=>setCategory(e.target.value)} /><br/>
                    <input placeholder="Enter Contact no." type='number' name='stock' value={contact_Info} onChange={(e)=>setContact_info(e.target.value)} /><br/>
                    <input placeholder="Enter Location" type='text' name='cat' value={location} onChange={(e)=>setLocation(e.target.value)} /><br/>
                    <input placeholder="Enter Operating Hours" type='text' name='stid' value={OperatingHours} onChange={(e)=>setOphr(e.target.value)} /><br/>
                    <button onClick={handelEve} className='btn add' type='submit'>Submit</button>
                </div>
            </form>
        </div>
    )
}
export default Upd;