import React from 'react';

function About()
{
    return(
        <main style={{textAlign:"left",fontSize:+25}}>
            <div class="container main">
            <h1>Welcome to Our Company</h1>
            <p>Our company is dedicated to providing the best products and services to our customers. We believe in quality, innovation, and customer satisfaction. Our team is composed of talented and passionate individuals who work tirelessly to meet and exceed your expectations.</p>
            <div class="team">
                <div class="team-member">
                    <img src={require('../Imgs/pic.jpeg')} alt="Team Member 1"/>
                    <h3>Abcd</h3>
                    <p>CEO</p>
                </div>
                <div class="team-member">
                    <img src={require('../Imgs/pic1.jpg')} alt="Team Member 2"/>
                    <h3>Pqrs</h3>
                    <p>CTO</p>
                </div>
                <div class="team-member">
                    <img src={require('../Imgs/pic2.png')} alt="Team Member 3"/>
                    <h3>Xyz</h3>
                    <p>COO</p>
                </div>
            </div>
            </div>
        </main>
    );
}
export default About;