import React,{useState} from 'react'
import Proser from '../Service/StoreService'

function Add()
{
    const [storeId,setId]=useState("");
    const [name,setName]=useState("");
    const [category,setCategory]=useState("");
    const [contact_Info,setContact_info]=useState("");
    const [location,setLocation]=useState("");
    const [OperatingHours,setOphr]=useState("");
    const obj={
        id:storeId,
        name:name,
        category:category,
        contact_Info:contact_Info,
        location:location,
        operatinghours:OperatingHours};
    const handelEve=(e)=>{
        e.preventDefault();
            Proser.createStores(obj)
            .then((res)=>{
                console.log(res);
            })
            .catch(err=>{
                alert(err);
            })
        alert("Store added successfully.,!");   
    }

    return(
        <div id="con">
            <h2>Add Store</h2>
            <form>
                <div>
                    <input placeholder="Enter Store Id" type='text' name='id' value={storeId} onChange={(e)=>setId(e.target.value)} /><br/>
                    <input placeholder="Enter  Name" type='text' name='name' value={name} onChange={(e)=>setName(e.target.value)} /><br/>
                    <input placeholder="Enter  Category" type='text' name='desc' value={category} onChange={(e)=>setCategory(e.target.value)} /><br/>
                    <input placeholder="Enter Contact no." type='number' name='stock' value={contact_Info} onChange={(e)=>setContact_info(e.target.value)} /><br/>
                    <input placeholder="Enter Location" type='text' name='cat' value={location} onChange={(e)=>setLocation(e.target.value)} /><br/>
                    <input placeholder="Enter Operating Hours" type='text' name='stid' value={OperatingHours} onChange={(e)=>setOphr(e.target.value)} /><br/>
                    <button onClick={handelEve} className='btn add' type='submit'>Submit</button>
                </div>
            </form>
        </div>
    )
}
export default Add;