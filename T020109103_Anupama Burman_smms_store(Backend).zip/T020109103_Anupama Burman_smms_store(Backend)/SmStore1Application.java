package com.tnsif.sm.store;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SmStore1Application {

	public static void main(String[] args) {
		SpringApplication.run(SmStore1Application.class, args);
	}

}
