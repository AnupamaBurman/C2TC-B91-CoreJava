package com.tnsif.sm.store;


import org.springframework.data.jpa.repository.JpaRepository;

public interface StoreRepository extends JpaRepository<Store,Integer>
{
	//all CRUD OPERATION METHODS

}
