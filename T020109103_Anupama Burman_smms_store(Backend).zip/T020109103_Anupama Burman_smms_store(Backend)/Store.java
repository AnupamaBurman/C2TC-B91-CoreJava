package com.tnsif.sm.store;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class Store {

private Integer storeId ;
private String name;
private String category;
private Double contact_Info;
private String location;
private Integer operatinghours;

//Constructor
public Store()
{

}

public Store(Integer storeId, String name, String category, Double contact_Info, String location,Integer operatingHours) {
	this.storeId = storeId;
	this.name = name;
	this.category = category;
	this.contact_Info = contact_Info;
	this.location = location;
	this.operatinghours = operatingHours;
}

@GeneratedValue(strategy=GenerationType.IDENTITY)
@Id
public Integer getStoreId() {
	return storeId;
}

public void setStoreId(Integer storeId) {
	this.storeId = storeId;
}

public String getName() {
	return name;
}

public void setName(String name) {
	this.name = name;
}

public String getCategory() {
	return category;
}

public void setCategory(String category) {
	this.category = category;
}

public Double getContact_Info() {
	return contact_Info;
}

public void setContact_Info(Double contact_Info) {
	this.contact_Info = contact_Info;
}

public String getLocation() {
	return location;
}

public void setLocation(String location) {
	this.location = location;
}

public Integer getOperatinghours() {
	return operatinghours;
}

public void setOperatinghours(Integer operatinghours) {
	this.operatinghours = operatinghours;
}



}
